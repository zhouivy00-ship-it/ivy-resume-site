---
name: 保安封面
description: 为小红书账号「风口保安」生成大鹅保安封面图。当用户说"做个保安封面"、"保安封面"、"用这个标题做张保安封面"、"大鹅封面"、"换个标题再出一张保安封面"，或给出一个标题并要求用那只保安大鹅做小红书封面时触发。用户只给标题即可，鹅的表情动作由标题内容拟人化推导。不适用于写文章正文（用「小比文章写作」）、不适用于略略略猴子封面（用 lueluelue-cover）、不适用于通用图片生成（用 create-image）。
---

# 保安封面制作

为小红书账号「风口保安」生成统一风格的 3:4 封面。用户给一个标题，你据标题内容重新发明大鹅的表情、动作、道具，把新闻情绪拟人化演出来，输出一张完整封面。

核心分工：**IP 形象和版式是固定的，表情/动作/道具是每次现编的。** 用户挑的是「这只鹅在干什么」，不是「换个滤镜」。

## IP 形象规范（固定不变）

- **物种**：白色卡通大鹅，橙色喙、橙色蹼足
- **脖子**：细长、有自然 S 形曲线，从制服领口里伸出来，小脑袋在顶端。这一条最容易翻车 —— 模型常把头直接怼在身体上，出图后必须检查脖子在不在
- **制服**：深藏蓝短袖保安服，翻领、正面门襟纽扣、两个带盖胸袋、黑色肩章带银条、黑腰带银扣
- **徽章**：金色盾牌 + 五角星 + 麦穗，左胸一枚；帽子正面一枚同款，只有大小差别。两枚必须同设计
- **帽子**：深藏蓝大檐帽，亮黑帽檐，银色帽带
- **画风**：扁平卡通矢量，粗黑描边，无渐变无写实质感

帽子可以按剧情飞出去、歪掉、压住眼睛，但形制不变。

## 随标题变化的部分

按标题的情绪和事实现编，不要套模板：

- **表情**：震惊→瞪成小圆点的眼珠+张嘴倒吸气；崩溃→蚊香眼+冒汗；偷感→眯眼斜瞄+捂嘴;得意→挑眉抱臂；麻了→半闭眼摊翅
- **动作**：后仰、前扑、失衡、蹲下、扒着看
- **道具**：把标题里的名词实体化。降价→划红杠的价签；迭代快→撕飞的日历页；算钱→冒烟的计算器；排队→取号条；裁员→纸箱
- **漫画符号**：汗滴、震惊线、速度线、星星眼，按情绪加

道具要能一眼读懂标题，别堆太多。上一版失败经验：右半边塞满价签和日历后缩略图糊成一团。日历、按钮上不要出现英文月份或英文单词，和中文标题割裂。

## 版式规范

- **比例**：3:4，2K
- **背景**：纯白（#FFFFFF），无米黄调、无纹理、无边框
- **标题**：粗黑体，画面上部，三行以内。字迹要**错落不规整** —— 每行缩进不同、逐行小角度反向倾斜、行内字号有大有小、最后一行最大最歪，可加一到两个手绘感叹号。用户明确不要「整整齐齐」的居中三行
- **重点标黄**：标题里 2-4 个关键字（数字、幅度、时间、公司名）后面垫一道手绘感的亮黄色马克笔涂痕，黑字压在上面
- **不要**：底部黄黑警示条（早期版本有，用户已否掉）
- **鹅的大小**：偏小，居于画面下部，四周留白充裕，不要顶满画框

白底下所有白色道具（价签、日历纸）只靠黑线撑边，缩略图容易发散。道具较多时给它们加一点浅灰底或淡投影拔出来。

## 生成流程

1. 读标题，定情绪 → 写出「表情 + 动作 + 道具」三件套
2. 组装 prompt：形象规范照抄，表情动作道具替换
3. 以 `assets/reference-goose-guard.png` 作为 `--input` 保持形象一致
4. 生成后**读回图片检查**：脖子在不在、两枚徽章是否同款、中文标题有没有错字缺字、有没有混进英文
5. 需要确认纯白背景时采样角点：`python3 -c "from PIL import Image;im=Image.open('<path>').convert('RGB');print(im.getpixel((5,5)))"`

一次给两版不同表情/动作方案让用户挑，附一句推荐理由和已知瑕疵。

## 生成参数

```bash
COMATE_USERNAME_ENCRYPTED="<env>" bash <SKILL_DIR>/../.system/create-image/scripts/generate-image.sh \
  --prompt "<组装的 prompt>" \
  --input <SKILL_DIR>/assets/reference-goose-guard.png \
  --output <标题关键词>-cover.png \
  --aspect-ratio 3:4 \
  --resolution 2K
```

图落在用户项目的 `images/` 目录。偶发 `curl: (56) Recv failure` 是网络抖动，原样重跑即可。

## Prompt 模板

```
Flat cartoon vector illustration, bold thick black outlines, PURE WHITE background (#FFFFFF), clean and flat edge to edge, no cream tint, no texture, no border, no bottom stripe band. 3:4 Xiaohongshu cover.

A cartoon WHITE GOOSE security guard, drawn small in the lower part of the frame with generous white breathing space around him. Long slender white goose neck with a natural S-curve rising OUT OF the uniform collar, small head on top — the neck must be clearly long and correctly proportioned, never squashed onto the body. Orange beak, orange webbed feet. Navy blue short-sleeve security uniform: collar, front button placket, two chest pockets with flaps, black epaulettes with silver bars, black belt with silver buckle. GOLD SHIELD BADGE with five-pointed star and laurel wreath on the LEFT CHEST. Navy blue peaked cap with shiny black brim, silver chin strap and the SAME gold shield badge on the front (cap badge and chest badge are identical designs, differing only in size).

Expression: {表情}. Pose and action: {动作}. Props: {道具}. Comic effects: {汗滴/震惊线/速度线等}.

Chinese title text in the upper area, heavy black poster typeface, {N} lines: "{第一行}" / "{第二行}" / "{第三行}". Typography is deliberately playful and irregular, NOT a tidy centered block: dramatic mixed character sizes inside each line, lines staggered at different horizontal indents, each line rotated a few degrees in alternating directions like torn paper strips pasted by hand, the last line largest and most tilted. A rough hand-drawn bright yellow highlighter swipe sits BEHIND the characters "{重点词1}" and "{重点词2}", black text fully readable on top. All text is Chinese only, no English words anywhere.
```

## 输出格式

用 HTML table 展示，单张 width=640，两张各 width=480。给出文件绝对路径，并主动说明本轮的已知瑕疵（徽章细节漂移、字形糊、道具挤压等），不要报喜不报忧。
