---
name: 小比封面图
description: 为小红书账号「小比」生成封面图。仅当用户明确提到“小比封面图”“小比的封面”“用小比小狗做封面”或类似明确请求时触发；用户提供标题即可生成 3:4 纯白背景封面，并根据标题自动设计小狗的表情、动作和简单道具。不适用于其他账号封面、文章写作或通用图片生成。
---

# 小比封面图

为小红书账号「小比」制作统一但不僵硬的 3:4 竖版封面。用户给出标题后，先理解标题的情绪和冲突，再让小狗用一个一眼能看懂的表情、动作和道具把标题演出来。

## 固定的角色形象

使用本 Skill 的 `assets/xiaobi-reference.png` 作为 `create-image` 的输入参考图。保留小狗的关键特征：

- 棕黄色垂耳，额头中央白色竖纹
- 白色口鼻和身体，棕黄色身体局部
- 黑色粗描边、可爱扁平卡通贴纸风
- 头大身短、圆润可爱、黑色鼻子和粉色腮红

角色的颜色、耳朵形状、脸部白色区域和整体轮廓不要改变。每张图只改变表情、姿势和道具。

## 根据标题变化

从标题中提炼一个核心情绪和一个视觉动作，避免堆砌元素：

- 愤怒或吐槽：皱眉、瞪眼、张嘴喊话、叉腰、指责、跺脚
- 委屈或被罚：眼含泪光、嘴角下撇、抱头、举罚单
- 震惊或反转：瞪大眼、张嘴、后仰、手里掉出道具
- 无语或摆烂：半闭眼、摊手、翻白眼、趴倒
- 得意或自嘲：挑眉、坏笑、举牌、指向自己

把标题中的关键名词实体化成一个简单道具，例如选票、罚款单、工位灰尘、纸箱、计算器或手机。道具只保留一个主道具，保证缩略图仍然清楚。

## 版式和字体

- 画布比例固定为 3:4，背景必须是纯白色
- 标题放在画面上方，小狗放在下方，留出舒适的呼吸空间
- 标题必须准确使用用户原文，不擅自改字、增字或删字
- 中文字体要可爱、活泼、有手写感，不要规整的企业宣传或新闻海报字体
- 允许每行有轻微错落、倾斜、大小变化，像真人制作的小红书封面
- 重点词可以使用红色或黄色手绘标记，但必须保持清晰易读
- 不添加无关文字、英文、logo、水印或复杂背景

## 生成流程

1. 读取用户标题，确定情绪、动作和一个主道具。
2. 使用 `assets/xiaobi-reference.png` 作为输入参考图，组装图像生成提示词。
3. 调用 create-image 的 `generate-image.sh`，参数使用 `--aspect-ratio 3:4` 和 `--resolution 2K`。
4. 输出文件放在当前项目的 `images/` 目录，文件名使用标题关键词加 `-cover-vN.png`，不要覆盖旧图。
5. 生成后用 HTML table 展示图片，单张图片宽度使用 640。

## Prompt 模板

```
Create a 3:4 vertical Xiaohongshu cover with a pure white background. Use the input image as the strict character reference. Keep exactly the same cute cartoon puppy: tan floppy ears, central white forehead stripe, white muzzle and body, tan patches, thick black outlines, round chibi proportions, pink cheek blush, flat sticker illustration style. Do not redesign the character; only change its expression, pose, and one simple prop.

Title text, exactly as provided by the user, placed in the upper area: "{标题}". Use cute lively hand-drawn Chinese typography, not a rigid corporate poster font. The lines may be slightly staggered, tilted, and varied in size while remaining highly legible. Use red or a hand-drawn yellow highlight for key words if helpful.

Expression: {标题对应的表情}.
Pose: {标题对应的动作}.
One clear prop: {标题对应的主道具}.

The puppy occupies the lower part with comfortable white space. No extra words, no English, no logos, no watermark, no people, no busy background.
```

## 输出

生成成功后只展示最终图片的 HTML table，并简短说明本轮采用的表情和动作。若中文标题出现错字、缺字或背景不是纯白，应重新生成一个递增版本，不要覆盖原文件。
