#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
interview_docx.py · 访谈纪要 docx 生成器

页面 A4 / 上2.5 下2.5 左3.0 右3.0 cm / 正文仿宋 12pt / 标题黑体 / 页脚页码居中。
结构：大标题 → 访谈信息块 → 关键数字总表 → 按提纲分部分逐题 → 提纲外增量 → 待核清单。

调用：
    from interview_docx import build_interview
    build_interview(data, output_path)

data schema:
    {
      "标题": "豆包市场部 访谈纪要",
      "访谈时间": "2026-07-10 10:59",
      "时长": "约 65 分钟",
      "访谈方": "第三方咨询公司（李慧）",
      "受访方": "豆包市场部专家",
      "来源": "/Users/x/Desktop/豆包访谈.docx",
      "说明": "数字均按受访者原话记录，[?待核] 处以原音频为准",
      "关键数字": [
          {"指标": "研发岗日均 AI 使用时长", "数值": "3.4 小时",
           "口径": "后台统计/日均", "位置": "06:12"},
      ],
      "部分": [
          {"名称": "第一部分：AI Agent 实际使用",
           "题目": [
               {"题号": "1", "题干": "公司内部正在推广 AI 融入工作流吗？",
                "覆盖": "完整",              # 完整 / 部分 / 未答
                "正文": ["段落一", "段落二"],
                "原话": ["“没有去强制说必须要使用怎样的” [01:48]"],
                "小表": {"表头": ["岗位", "时长"],
                         "行": [["研发岗", "3.4 小时"]]}},
           ]},
      ],
      "提纲外": [{"小标题": "五月战略转向", "正文": ["..."]}],
      "待核": ["token 日消耗量级需核 [08:42]"],
    }
所有字段可缺省；缺省即跳过对应块。
"""
import os

from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_ALIGN_VERTICAL

from consult_docx_utils import set_run_font, add_para, setup_page, add_page_field

BODY_FONT = "仿宋"
HEAD_FONT = "黑体"
TABLE_FONT = "微软雅黑"
BODY_SIZE = 12
TABLE_SIZE = 10.5


# ============ 基础块 ============

def _big_title(doc, text):
    add_para(doc, text, font=HEAD_FONT, size=17, bold=True,
             align="center", space_after=12)


def _h1(doc, text):
    add_para(doc, text, font=HEAD_FONT, size=15, bold=True, space_after=6)


def _h2(doc, text):
    add_para(doc, text, font=HEAD_FONT, size=13, bold=True, space_after=4)


def _body(doc, text, indent=True):
    add_para(doc, text, font=BODY_FONT, size=BODY_SIZE,
             space_after=6, indent_first=indent)


def _quote(doc, text):
    """受访者原话——楷体缩进，与正文区分。"""
    p = add_para(doc, text, font="楷体", size=BODY_SIZE, space_after=6)
    p.paragraph_format.left_indent = Cm(1.0)
    return p


def _write_cell(cell, text, bold=False, center=False):
    cell.text = ""
    p = cell.paragraphs[0]
    if center:
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for i, line in enumerate(str(text).split("\n")):
        if i > 0:
            p = cell.add_paragraph()
            if center:
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(line)
        set_run_font(run, TABLE_FONT, TABLE_SIZE, bold)
    cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER


def _table(doc, header, rows):
    """通用表格：首行加粗居中。"""
    if not header:
        return None
    t = doc.add_table(rows=1 + len(rows), cols=len(header))
    t.style = "Table Grid"
    for j, h in enumerate(header):
        _write_cell(t.rows[0].cells[j], h, bold=True, center=True)
    for i, row in enumerate(rows, start=1):
        for j, val in enumerate(row):
            if j < len(header):
                _write_cell(t.rows[i].cells[j], val)
    add_para(doc, "", size=BODY_SIZE, space_after=6)
    return t


# ============ 主构建函数 ============

def build_interview(data, output_path):
    doc = Document()
    setup_page(doc, top=2.5, bottom=2.5, left=3.0, right=3.0)

    # 页脚页码
    footer_p = doc.sections[0].footer.paragraphs[0]
    footer_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    add_page_field(footer_p, font_name=BODY_FONT, size=10.5,
                   label_with_total=True)

    _big_title(doc, data.get("标题", "访谈纪要"))

    # ---- 访谈信息块 ----
    info_pairs = [
        ("访谈时间", data.get("访谈时间")),
        ("时长", data.get("时长")),
        ("访谈方", data.get("访谈方")),
        ("受访方", data.get("受访方")),
        ("来源", data.get("来源")),
    ]
    info_rows = [[k, v] for k, v in info_pairs if v]
    if info_rows:
        _table(doc, ["项", "内容"], info_rows)
    if data.get("说明"):
        _body(doc, "说明：" + data["说明"], indent=False)

    # ---- 关键数字总表 ----
    nums = data.get("关键数字") or []
    if nums:
        _h1(doc, "关键数字总表")
        _table(doc, ["指标", "数值", "口径/条件", "位置"],
               [[n.get("指标", ""), n.get("数值", ""),
                 n.get("口径", ""), n.get("位置", "")] for n in nums])

    # ---- 按提纲分部分 ----
    for part in data.get("部分") or []:
        _h1(doc, part.get("名称", ""))
        for q in part.get("题目") or []:
            num = q.get("题号", "")
            stem = q.get("题干", "")
            title = f"{num}、{stem}" if num else stem
            cover = q.get("覆盖")
            if cover and cover != "完整":
                title = f"{title}【{cover}】"
            _h2(doc, title)
            for para in q.get("正文") or []:
                _body(doc, para)
            tbl = q.get("小表")
            if tbl and tbl.get("表头"):
                _table(doc, tbl["表头"], tbl.get("行") or [])
            for quote in q.get("原话") or []:
                _quote(doc, quote)

    # ---- 提纲外增量 ----
    extras = data.get("提纲外") or []
    if extras:
        _h1(doc, "提纲外增量信息")
        for item in extras:
            if item.get("小标题"):
                _h2(doc, item["小标题"])
            for para in item.get("正文") or []:
                _body(doc, para)

    # ---- 待核清单 ----
    pending = data.get("待核") or []
    if pending:
        _h1(doc, "待核清单")
        for i, item in enumerate(pending, start=1):
            _body(doc, f"{i}. {item}", indent=False)

    out_dir = os.path.dirname(os.path.abspath(output_path))
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    doc.save(output_path)
    return output_path


if __name__ == "__main__":
    demo = {
        "标题": "示例产品 市场部 访谈纪要",
        "访谈时间": "2026-08-19 10:00",
        "时长": "约 60 分钟",
        "访谈方": "调研方",
        "受访方": "市场部负责人",
        "说明": "数字均按受访者原话记录",
        "关键数字": [
            {"指标": "日均 AI 使用时长", "数值": "1.8 小时/人",
             "口径": "6 月 · 市场部", "位置": "13:53"},
        ],
        "部分": [{
            "名称": "第一部分：AI 使用情况",
            "题目": [{
                "题号": "1", "题干": "是否强制使用 AI？", "覆盖": "完整",
                "正文": ["鼓励，不强制。[01:35]"],
                "原话": ["“没有去强制说必须要使用怎样的” [01:48]"],
                "小表": {"表头": ["岗位", "渗透率"],
                         "行": [["研发", "95%"], ["创意", "80%"]]},
            }],
        }],
        "提纲外": [{"小标题": "补充信息", "正文": ["受访者主动提到的内容。[46:24]"]}],
        "待核": ["某数字量级需回听确认 [08:42]"],
    }
    path = build_interview(demo, "/tmp/interview_demo.docx")
    print("written:", path)
