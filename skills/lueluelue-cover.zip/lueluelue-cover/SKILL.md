---
name: lueluelue-cover
description: 为小红书账号「略略略」生成封面图。当用户说"帮我做略略略封面"、"出个略略略的封面"、"略略略封面"、"帮略略略出封面"、"用这个标题做封面"、"换个标题再出一张"，或任何明确提到为「略略略」账号制作小红书封面的请求时触发。用户给出标题即可生成，也可额外指定猴子的表情或动作。不适用于写文章内容（用小比文章写作）、不适用于通用图片生成（用create-image）。
---

# 略略略封面制作

为小红书账号「略略略」生成统一风格的封面图。用户提供标题，你根据标题情绪匹配猴子的表情和动作，输出一张完整封面。

## IP形象规范（固定不变）

猴子角色的以下特征在任何封面中都必须保持一致：

- **体型**：大头短身 chibi 比例（头部几乎和身体一样大），矮胖敦实
- **毛色**：深灰棕色（带明显笔触纹理的深灰棕，不是浅色也不是纯黑）
- **肚子**：浅肤色/浅米色区域
- **头发**：顶部浓密蓬松尖刺状，深灰棕色，毛量感强
- **耳朵**：大圆耳，内部粉色，位置偏低（在头部两侧靠下方）
- **眉毛**：超粗黑锐角眉，表情感强烈
- **眼睛**：大眼睛 + 棕色瞳孔，眼白面积大
- **工牌**：荧光绿挂绳 + 黄绿色小方形牌子，默认写"略略略"
- **尾巴**：长卷尾，尾尖黑色
- **毛发质感**：有明显的手绘笔触纹理（可见毛发方向感），但不是写实动物——是有质感的卡通风格
- **画风**：粗黑线描边，手绘笔触感强烈，办公室打工人吉祥物气质，不是光滑矢量风也不是写实风

## 会随标题变化的部分

- **表情**：配合标题情绪（震惊→瞪眼张嘴 / 无奈→摊手半闭眼 / 吐槽→翻白眼 / 得意→嘴角上扬竖拇指 / 摆烂→摆手不在乎）
- **动作/姿势**：配合标题（摊手/抱臂/捂脸/竖拇指/摆手等）
- **工牌文字**：默认"略略略"，用户可指定其他文字

如果用户额外指定了表情或动作，按用户要求来；如果没有指定，根据标题语气自行匹配最贴切的情绪。

## 封面布局规范

- **比例**：3:4（小红书封面标准竖版）
- **背景**：纯白色
- **标题文字**：大号加粗黑色字体，位于画面上方居中
- **猴子大小**：约占画面35-40%高度
- **布局**：文字和猴子保持均衡间距（不过于紧凑也不留大空隙），整体内容垂直居中
- **风格**：干净、简洁、不刺眼、不夸张

## 生成流程

1. 接收用户提供的标题
2. 分析标题情绪，确定猴子的表情和动作（或使用用户指定的）
3. 组装prompt，严格遵循IP形象规范和布局规范
4. 使用 create-image 的 generate-image.sh 脚本生成图片
5. 以参考图作为 --input 保持猴子形象一致性

### 参考图选择规则（关键）

`--input` 参考图**必须是一张已有的略略略猴子封面**，绝对不能用其他角色（如风口保安的鹅）的图。这是保持猴子形象一致的核心机制。

选择优先级：
1. 用户项目 images/ 目录下最近生成的略略略封面
2. 如果没有历史封面，使用 `<用户项目目录>/images/ai-write-cover-v10.png` 作为初始种子图（这是经用户确认的标准形象）

参考图只提供角色造型约束，表情和动作完全由 prompt 控制。

## 生成参数

```bash
COMATE_USERNAME_ENCRYPTED="<env>" bash <SKILL_DIR>/../.system/create-image/scripts/generate-image.sh \
  --prompt "<组装的prompt>" \
  --input <用户项目目录>/images/<最近一张略略略封面作为参考> \
  --output <基于标题的文件名>.png \
  --aspect-ratio 3:4 \
  --resolution 2K
```

## Prompt模板

```
Xiaohongshu cover image in 3:4 vertical format. Pure white background. Content is vertically CENTERED with balanced spacing between elements. Bold title text "{标题}" in EXTRA LARGE bold black font, occupying about 30-35% of the image height, in the upper-center area. The title font size must be consistent regardless of text length — shorter titles use bigger characters, longer titles can wrap to 2 lines but stay the same visual weight. Below with balanced comfortable spacing, a cartoon monkey character (about 35-40% of image height). CRITICAL: The monkey MUST look EXACTLY like the one in the reference image — same big-head chibi proportions (head is almost as large as body), same short stubby body, same thick dark fur texture with visible brushstrokes, same ear size and low placement on head, same overall silhouette. DO NOT change the character design in any way. Only change the EXPRESSION and POSE: {根据标题匹配的表情动作描述}. Badge on lanyard says "{工牌文字，默认略略略}". MANDATORY CHARACTER DESIGN (copy EXACTLY from reference): dark grayish-brown fur with visible brushstroke texture, lighter cream belly area, spiky messy hair on top same dark gray-brown color, large round pinkish ears placed low on the sides of the big round head, very thick angular black eyebrows, large expressive eyes with brown pupils, wearing a fluorescent GREEN lanyard with small rectangular yellow-green badge saying "略略略", long curving tail with black tip. Style: cartoon with thick black outlines and visible hand-drawn brushstroke texture on fur — NOT smooth vector, NOT realistic, but textured cartoon mascot style. Overall layout is centered and balanced.
```

## 输出格式

生成后用HTML table展示图片，单张图片width=640。文件保存在项目的 images/ 目录下。
