# 取数、核验与事实纪律

## 先找 opencli，别先判断自己在哪

取数能力只取决于一件事：**能不能找到并执行 opencli**。

`opencli` 常装在 `~/.local/bin`，而执行命令的 shell 未必继承用户交互 shell 的 PATH。实测：`env -i /bin/sh -c 'command -v opencli'` 返回空，但 `/Users/xxx/.local/bin/opencli --version` 正常输出 1.8.7。所以裸探测会假阴性，**必须多路径找 + 绝对路径调用**：

```bash
OPENCLI=""
for p in "$(command -v opencli 2>/dev/null)" \
         "$HOME/.local/bin/opencli" \
         "/opt/homebrew/bin/opencli" \
         "/usr/local/bin/opencli" \
         "$HOME/.npm-global/bin/opencli" \
         "$HOME/node_modules/.bin/opencli"; do
  [ -n "$p" ] && [ -x "$p" ] && OPENCLI="$p" && break
done
[ -n "$OPENCLI" ] && echo "OPENCLI_OK: $OPENCLI" || echo "NO_OPENCLI"
```

没找到时再补两下确认，别急着放弃：

```bash
ls -l "$HOME/.local/bin" 2>/dev/null | grep -i opencli
npx --yes @jackwener/opencli --version 2>&1 | head -2
```

- 任意一步能跑通 → 走通道 A，后续命令全部用绝对路径或 `npx` 前缀
- 确实都不行 → 走通道 B，此时才需要检查环境变量

**这道坑已经害过一次**：opencli 装在 `~/.local/bin` 且完全可用，skill 用裸 `command -v` 探测失败，自己切到云端模式、报了一串变量 MISSING，把唯一能用的主力源丢掉了。同一份素材在别人的包里能正常抓，差别只在有没有做这个多路径查找。

## 云端为什么抓不到小红书（架构限制，不要再试）

opencli 的取数不是纯 HTTP，它靠一条本机链路：

```
opencli CLI  →  本机 daemon（固定 127.0.0.1:19825）  →  Chrome 扩展（v1.0.22）  →  已登录的页面
```

实测确认过三件事：

- `opencli doctor` 正常时输出 `Daemon: running on port 19825` + `Extension: connected`
- daemon 地址硬编码在 `127.0.0.1`，端口常量 `DEFAULT_DAEMON_PORT = 19825`
- 源码里明确写着 `OPENCLI_DAEMON_PORT is no longer supported`，也没有任何 host 配置项

所以云端环境里 `npx @jackwener/opencli --version` 能跑通只代表 CLI 装上了，**它连不到任何浏览器扩展，必然报 `Browser Bridge extension not connected`**。这不是配置缺失，不是 skill 写错，是 opencli 只支持同机桥接。

云端遇到这个报错时的正确反应：一句话说明「云端没有浏览器桥，小红书和脉脉这两个主力源在这里拿不到」，然后按下面的分工走，**不要反复重试、不要试图装扩展、不要编造抓到的内容**。

## 本地与云端的分工

- **抓瓜（阶段一）留在本地**：本机有 Chrome + 扩展 + daemon，是唯一能拿到登录态数据的地方
- **云端做阶段一点五和阶段二**：用户把本地跑出来的选题表或爆料原文粘进来，云端负责新瓜核验（联网搜索就够）、打分复核、写稿

云端只有在用户明确提供了素材时才继续；素材没给就直接说明缺什么，别自己找替代数据凑一张表。

## 可选凭证（只对不依赖浏览器的路径有用）

| 变量名 | 用途 | 缺失后果 |
|---|---|---|
| `EXA_API_KEY` | Exa 搜索，用于新瓜核验和公司回应核实 | 核验只能靠平台自带联网搜索 |
| `JINA_KEY` | r.jina.ai 读网页提额 | 免费额度下经常直接超时 |
| `XHS_COOKIE` | 尝试不经浏览器直连小红书 web 接口。小红书有签名风控，成功率低，只当补充 | 少一条低成功率的备用路径 |

检查方式，只报 set / MISSING，**不要把凭证值打印出来**：

```bash
for v in EXA_API_KEY JINA_KEY XHS_COOKIE; do
  [ -n "${!v}" ] && echo "$v: set" || echo "$v: MISSING"
done
```

这三个都缺也能做新瓜核验和写稿，**不要因为它们 MISSING 就停下来**。

## 通道 A：opencli（唯一能拿到登录态数据的路径）

先跑 `"$OPENCLI" doctor` 确认链路：输出里同时出现 `Daemon: running on port 19825` 和 `Extension: connected` 才算真的可用。

```bash
"$OPENCLI" xiaohongshu user 644f177e000000001f0313af --limit 5 -f json
```

返回 JSON 数组就是通的。返回 `Browser Bridge extension not connected` 说明这个环境没有浏览器桥，直接走通道 B，不要重试。返回空数组说明命令和桥都在但页面侧没就绪，让用户开着 Chrome 手动访问一次小红书再重试一次。主力命令：

```bash
# 爆料号主页遍历，最容易抓到当天新帖
"$OPENCLI" xiaohongshu user USER_ID --limit 20 -f json

# 关键词搜索作为补充（经常整批返回空数组，别当故障）
"$OPENCLI" xiaohongshu search "某脉" --limit 30 -f json
"$OPENCLI" xiaohongshu search "大厂裁员" --limit 30 -f json

# 读正文（标题党很多，判断有没有料的关键一步）
"$OPENCLI" xiaohongshu note "完整URL含xsec_token" -f json

# 脉脉职言
"$OPENCLI" maimai gossip --limit 50 --site-session persistent -f json
```

`note` 返回的是 `[{"field":"title","value":...}, ...]` 这种字段列表，解析时要先转成字典：

```python
d = {x['field']: x['value'] for x in json.load(sys.stdin)}
```

已验证账号清单见 `accounts.md`。

## 通道 B：没有浏览器桥时（数字员工）

这条通道拿不到小红书和脉脉，**它的产出只能是「待核线索」，不能当「今日有效瓜」**。按顺序试：

**B1. 小红书 web 接口 + `XHS_COOKIE`**（低成功率，有 Cookie 才试）

```bash
curl -s "https://edith.xiaohongshu.com/api/sns/web/v1/user_posted?num=20&user_id=USER_ID" \
  -H "Cookie: $XHS_COOKIE" \
  -H "User-Agent: Mozilla/5.0" \
  -H "Referer: https://www.xiaohongshu.com/"
```

小红书对 web 接口有签名和风控，Cookie 过期或缺签名头时返回 `461`/`406`。**拿到错误码就如实说明被风控拦了，不要反复重试刷验证码，也不要改用搜索引擎假装抓到了。**

**B2. 零配置公开源**（不需要任何凭证）

```bash
# V2EX 热议（实测稳定可用，无需 key）
curl -s --max-time 20 "https://www.v2ex.com/api/topics/hot.json" -H "User-Agent: agent-reach/1.0"

# 微博/知乎榜单（经 r.jina.ai 代读，注意这条在部分网络环境下完全不通，返回 HTTP 000）
curl -sL --max-time 30 "https://r.jina.ai/https://tophub.today/n/KqndgxeLl9"
curl -sL --max-time 30 "https://r.jina.ai/https://tophub.today/n/mproPpoq6O"
```

`r.jina.ai` 在没有 `JINA_KEY` 时限流严重，本机实测直接超时（HTTP 000）。**试一次不通就放弃这条，不要重试三遍浪费时间**，也不要因为它不通就宣布整个抓取失败。

**B3. 平台自带的联网搜索工具**（`bash`/`curl` 全被拦，或者上面都不通时）

数字员工一般自带联网搜索能力。用它搜「大厂 裁员 爆料 <今天日期>」「脉脉 爆料 <公司名>」这类词。

这条路径拿到的东西**只能进「待核线索」表，绝对不能进「今日有效瓜」**：搜索引擎收录滞后、混营销号文章、时间不可信，这三点没法靠提示词绕过。

**B4. 都不通**：直接告诉用户「这个环境没有浏览器桥，抓不到小红书和脉脉」，说明卡在哪一步，然后请用户把本机跑出来的选题表、爆料截图或原文粘进来，跳到阶段一点五和阶段二。

## 全部环境变量都 MISSING 时怎么办

这是数字员工上最常见的状态，**不要停在这里等用户配置**。按这个顺序处理：

1. 照样跑完 B2（V2EX）和 B3（平台搜索），把能拿到的东西整理成「待核线索」表
2. 在输出开头一句话说明：这个环境没有浏览器桥，小红书和脉脉这两个主力源不可用，所以没有「今日有效瓜」，只有线索
3. 给用户两个明确选项，让他自己选，别替他决定：
   - 在本机 IDE 里跑阶段一（那里有 Chrome 和扩展），把选题表粘过来，这边接着做核验和写稿
   - 或者直接把爆料截图、原文粘过来，跳过阶段一
4. 不要因为没有数据就自己编瓜，也不要把 V2EX 上的技术讨论包装成大厂职场爆料


**入口不可用 ≠ 今天没有瓜**，这两件事必须在输出里分清楚。

## 禁止的降级路径

不管在哪种模式下：

- 不要用搜索引擎搜「大厂裁员」之类的词充当小红书和脉脉的替代。收录滞后，拿不到近 24 小时新帖，结果里混大量旧内容和营销号文章
- 不要把超出 24 小时的内容放进「今日有效瓜」
- 不要把行业新闻、公众号文章、社会新闻改写成「爆料」
- 不要因为通道不通就自己「合理推测」一条瓜出来

## 时间判断（精确到秒）

小红书主页返回的 `published_at` 常为 `None`，但**笔记 ID 前 8 位是十六进制 Unix 时间戳**：

```python
import datetime
datetime.datetime.fromtimestamp(int(note_id[:8], 16))
# '6a8a5cbc...' -> 2026-08-23 10:36:12
```

按 ID 倒序等于按时间倒序。卡 24 小时窗口时先算阈值 `hex(int((now - 24h).timestamp()))`，再逐条比对 ID 前 8 位，**不需要**为了拿时间逐条调 `note`（几十次调用会触发验证码）。

## 脉脉的已知限制

- 匿名态也能读到内容，`whoami` 返回 anonymous 属正常
- 返回内容可能是 mojibake（UTF-8 被按 GBK 解码），用 `s.encode('gbk').decode('utf-8')` 修复
- 返回的 `time` / `author` / `likes` / `comments` 多为空，没有 URL
- 一篇长帖会被拆成多个段落，rank 连续的段落通常属于同一帖
- **同一时间窗口内重复拉取返回相同内容**，连拉 10 轮不会有增量

所以脉脉内容默认进「待核线索」，除非能补到原帖截图或对应的小红书搬运帖。

## 封面截图核验（判断有没有脉脉原帖截图）

用户优先要带脉脉原帖截图的瓜，但标题和字段里看不出封面是什么，只能把图拉下来看。主页返回的 `cover` 就是首图：

```bash
curl -s -o /tmp/c1.webp "COVER_URL"
sips -s format png /tmp/c1.webp --out /tmp/c1.png   # 本地 macOS；云端用 Pillow 转
```

然后读图，按这四类判断：

- **脉脉原帖截图**：浅灰底、圆角卡片、左上有头像和打码昵称，常带「# 我来爆个料」「职言」标签，正文是当事人第一人称。这类是一手信源，最优先，打分 +2，标注 `📸脉脉一手`
- **论坛/知乎/夜间模式帖子截图**：深色底或白底纯文本段落，也算原帖素材，可用但要注明来源不明
- **纯文字排版封面**：绿底大字、白底标题模板，说明搬运号手上也只有二手概括，往下压
- **新闻媒体截图**：带媒体名和发布时间。**必须把截图里的日期读出来跟 24 小时窗口比**，媒体稿 08-22、搬运号 08-24 才转的，对读者已经不是新瓜，要在表里写明原始日期

一次核 4-6 张就够，挑打分靠前的候选看。

## 去重

按**标题和内容主题**去重，不是按 URL。多个搬运号会转同一条脉脉内容，URL 不同但是一个瓜。同一瓜保留信息最完整、有截图的那条。

## 事实红线

爆料是单方信息，写的时候：

- 原帖没说的补偿金额、N+几、政策文件、内部指标一律不编，可以写「钱应该不少」「具体她没说」
- 当事人身份保持原帖颗粒度，不推测公司内具体部门和姓名
- 涉及未通报的违法指控，加「据爆料」「帖子里说」这类限定
- 转述时保留可核对的锚点（时间、工龄、职级、平台来源）
- 素材说「网传」就写「网传」

## 黑话与代号

| 黑话 | 含义 |
|---|---|
| cy / 广进 | 裁员、优化 |
| 大礼包 | 离职赔偿 |
| N+1 / 2N | 赔偿方案 |
| 活水 | 内部转岗 |
| 套改 | 职级体系调整 |
| PIP | 绩效改进计划（通常是劝退前置） |
| OD | 华为外包/第三方合同 |

| 代号 | 公司 |
|---|---|
| 宇宙厂 | 字节 |
| 福报厂 | 阿里 |
| 鹅厂 | 腾讯 |
| 狼厂 / 熊厂 | 百度 |
| 开水团 | 美团 |
| 老铁厂 | 快手 |
| 菊厂 / 华子 | 华为 |
| X 程 | 携程 |
| 拼厂 | 拼多多 |


