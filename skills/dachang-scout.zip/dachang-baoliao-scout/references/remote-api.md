# 远程取数接口（让无浏览器环境也能抓到当天新帖）

## 为什么要有这一层

opencli 取数必须经过用户本机 Chrome 的扩展：

```
opencli CLI → 本机 daemon(127.0.0.1:19825) → Chrome 扩展 → 已登录的小红书页面
```

daemon 地址硬编码在本机，`OPENCLI_DAEMON_PORT` 在 1.8.7 里已废弃。所以数字员工这类云端环境里 `npx @jackwener/opencli --version` 能输出版本号，但一抓就报 `Browser Bridge extension not connected`。

解决办法是反过来：用户本机起一个只读 HTTP 服务把 opencli 包起来，用隧道暴露地址，云端来调。

## 用户侧怎么起（本机操作）

```bash
# 1. 起服务，token 自己生成一个随机串
GUA_API_TOKEN=$(python3 -c "import secrets;print(secrets.token_urlsafe(24))")
echo "$GUA_API_TOKEN"          # 记下来，要填到数字员工的环境变量里
GUA_API_TOKEN="$GUA_API_TOKEN" python3 scripts/serve_gua_api.py --port 8787 &

# 2. 起隧道，拿公网地址
npx --yes localtunnel --port 8787
# 输出形如 your url is: https://xxxx-xxxx-xxxx.loca.lt
```

隧道工具选型是实测出来的：**cloudflared 在这个网络环境下不可用**，它 POST `api.trycloudflare.com/tunnel` 会一直超时（同一域名 curl GET 返回 405，说明域名可达，是隧道注册被拦）。localtunnel 一次就通。`bore.pub` 也不通。

## 云端怎么调

两个变量：`GUA_API_URL`（隧道地址）、`GUA_API_TOKEN`（上面生成的串）。

```bash
# 链路体检，无需 token
curl -s -m 20 -H "bypass-tunnel-reminder: 1" "$GUA_API_URL/health"

# 取最近 24 小时候选
curl -s -m 240 \
  -H "bypass-tunnel-reminder: 1" \
  -H "Authorization: Bearer $GUA_API_TOKEN" \
  "$GUA_API_URL/gua?hours=24&limit=20"
```

`bypass-tunnel-reminder` 这个头不能省。localtunnel 的免费域名首访会返回一个提醒页，漏了这个头拿到的就是 HTML 而不是 JSON。

## 返回结构

`/health`：

```json
{"opencli": "/Users/xxx/.local/bin/opencli", "bridge_ok": true, "doctor": ["..."]}
```

`bridge_ok` 为 `true` 才说明用户 Chrome 侧连着，为 `false` 时请用户打开 Chrome 访问一次小红书。

`/gua`：

```json
{"generated_at": "2026-08-26 11:08:46", "window_hours": 24, "accounts_scanned": 8,
 "count": 19, "items": [{"id": "...", "published_at": "2026-08-26 10:10:15",
 "title": "...", "likes": "1", "url": "https://...", "cover": "http://..."}]}
```

`published_at` 是从笔记 ID 前 8 位换算出来的真实发布时间，直接可用，不用再自己算。

## 接口只给列表

服务端只遍历爆料号主页，不读正文、不下载封面。所以拿到 items 之后：

- 要判断有没有料，用返回的 `url` 让用户在本机补一条 `opencli xiaohongshu note`
- 要判断有没有脉脉原帖截图，把 `cover` 拉下来看图（判断标准见 `source-and-accuracy.md`）
- 只凭标题也能先打一轮分，但正文没看过就别把推荐指数打到五星

## 故障对照

- 超时 / 502：用户机器或隧道没开。说明情况，**不要重试三遍**
- 401：token 不对，请用户核对 `GUA_API_TOKEN`
- 返回 HTML：漏了 `bypass-tunnel-reminder` 头
- `bridge_ok: false`：Chrome 没开或扩展没连
- 地址失效：localtunnel 免费域名在进程重启后会换，`GUA_API_URL` 要重新填

## 安全边界

服务只读，只返回公开笔记的标题、链接、时间、互动量、封面地址。不接受写操作，不返回 Cookie、不返回本机路径以外的任何凭证，token 不匹配直接 401。用户随时可以 `pkill -f serve_gua_api.py` 停掉。
