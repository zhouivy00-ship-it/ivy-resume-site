# 大厂瓜流水线 · 安装说明

一条流跑完「抓瓜 → 打分选题 → 写稿」：

1. 阶段一出两张表，都带推荐指数（五维打分，满分 10）、都可溯源，但**优先级完全不同**
   - **主表「今日有效瓜」**：最近 24 小时的大厂职场爆料，这是主线。脉脉一手原帖（有截图/原文，+2 分）排最前，小红书搬运的脉脉二手概括排后面
   - **备选选题库「科技热点」**：微博/知乎/澎湃/财联社/头条等公开热榜和新闻网里跟科技相关的热点与社会热点，48 小时窗口，编号用「备1 备2」。默认不推荐，只在主表空、主表全是高风险选题、或你明确说想写热点时才用
2. 出表后停住，等你报选题编号
3. 阶段二按你选的编号写成一篇小红书稿（主标题 + 三个备选 + 正文），三个号【略略略】【AI赛级比格】【风口保安】共用

备选池走的是免鉴权的 HotWordsLatest 榜单接口，纯 HTTP，不依赖浏览器扩展，所以 opencli 挂了也照样能出。但便宜不等于优先，两张表不混排、不比大小，主表有货就写主表。

目录结构（对齐数字员工可用的包格式）：

```
dachang-baoliao-scout/
├── SKILL.md                     流程主干：探通道 → 打分 → 停等 → 写稿
├── agents/openai.yaml           数字员工侧的 agent 声明与环境变量清单
├── assets/                      预留（当前无素材）
└── references/
    ├── source-and-accuracy.md   主表取数通道（本地/云端）、环境变量、截图核验、事实红线
    ├── tech-hotnews.md          备选池取数通道（榜单接口/站点适配器）、科技相关性门槛、打分去重
    ├── account-profile.md       三个号定位、70/30 配比、交付格式
    ├── style-guide.md           排版硬规则、语气、正文结构、拉踩
    ├── harness-gold-samples.md  标题公式与爆款样本
    └── accounts.md              已验证爆料号清单
```

## 数字员工上怎么用（已验证可行）

opencli 必须经过你本机 Chrome 的扩展，云端连不过来。解法是本机起一个只读接口 + 隧道，云端来调。

**本机两条命令：**

```bash
# 1. 起服务（记下打印出来的 GUA_API_TOKEN）
python3 scripts/serve_gua_api.py --port 8787

# 2. 另开一个终端起隧道，拿到 https://xxx.loca.lt
npx --yes localtunnel --port 8787
```

**数字员工里填两个变量：**

- `GUA_API_URL` = 隧道给的那个地址
- `GUA_API_TOKEN` = 起服务时打印的 token

之后它跑阶段一就会自己调 `/gua?hours=24` 取当天候选，照常出带推荐指数的选题表。

隧道工具别用 cloudflared，实测它注册 quick tunnel 会超时（`api.trycloudflare.com` 域名可达但 POST 被拦），localtunnel 一次就通。

三个限制：你的机器和 Chrome 要开着；localtunnel 免费域名在进程重启后会换，`GUA_API_URL` 得重新填；免费隧道没有可用性保证，偶尔会断。

接口只读，只返回公开笔记的标题、链接、时间、互动量、封面地址，不接受写操作，不返回任何凭证。随时 `pkill -f serve_gua_api.py` 可停。

细节见 `references/remote-api.md`。

## 安装

把 `dachang-baoliao-scout/` 整个目录放到 skills 目录下：

- Comate：`~/.comate/skills/`
- Claude Code：`~/.claude/skills/`

重启 IDE 或 CLI 后生效。说「抓一下今天的大厂瓜」即可触发。

## 依赖

这个 skill 靠外部 CLI 取数，装好才能跑。

**opencli**（必需，小红书 + 脉脉主力通道）

```bash
npm install -g @jackwener/opencli
```

opencli 通过浏览器扩展取数，需要：

1. Chrome 保持开着
2. 装上 opencli 的浏览器扩展
3. 浏览器里访问过 `xiaohongshu.com` 和 `maimai.cn`（脉脉匿名态可读，不必登录，但要访问过）

**agent-reach**（可选，只用来做通道体检 `agent-reach doctor --json`）。**没有它不影响抓取**。如果你的 agent 报告「因为没有 agent-reach 所以抓不到」，那是误判——真正缺的是 opencli 或浏览器扩展。

**Exa MCP**（可选，用于核实公司回应和事件背景）配置后可用 `mcporter call 'exa.web_search_exa(...)'`。没配就跳过，不影响主流程。

## 验证能不能跑

```bash
opencli xiaohongshu user 644f177e000000001f0313af --limit 5 -f json
```

返回 JSON 数组就是通的。返回空数组或报错，先检查 Chrome 和扩展。

## 已知限制

- 脉脉返回的元数据（时间/作者/点赞/链接）基本为空，所以脉脉内容默认只进「待核线索」，不当有效瓜用。
- 脉脉同一时间窗口内重复拉取返回相同内容，短时间连拉没有增量。
- 账号清单里少数号可能已注销或改 ID，返回空直接跳过。
- 微博/知乎/V2EX 大多数时候没有大厂职场爆料，筛完为空是正常的（它们在备选池里当热点源用，不指望出爆料）。
- 备选池的榜单接口是内网地址，公网环境拉不到，这时备选池会为空，需要换到内网或改用 opencli 的站点适配器。
- 榜单细分榜（微博科技数码热榜、抖音社会榜等）经常返回空数组，是上游没数据，不是故障。

## 配套

- 封面图：各账号有单独的 cover skill。
- 想定时抓：配合 Comate Automation 的 cron 定时任务，结果落盘成 Markdown（只跑阶段一，写稿仍由你点单）。
