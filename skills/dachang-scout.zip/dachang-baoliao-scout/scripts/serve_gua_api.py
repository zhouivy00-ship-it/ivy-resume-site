#!/usr/bin/env python3
"""把本机 opencli 的抓取能力包成一个只读 HTTP 接口，供数字员工等外部环境调用。

为什么需要它：opencli 取数必须经过本机 Chrome 扩展（CLI → 127.0.0.1:19825 daemon → 扩展），
云端环境没有这条链路，所以只能由本机提供服务、外部来调。

启动:
    GUA_API_TOKEN=你的随机token python3 serve_gua_api.py            # 只监听本机
    GUA_API_TOKEN=... python3 serve_gua_api.py --host 0.0.0.0       # 允许外部访问（配合隧道）

接口:
    GET /health                       无需鉴权，返回 opencli 链路状态
    GET /gua?hours=24&limit=20        需要 Authorization: Bearer <token>

安全边界：只读，只返回公开笔记的标题/链接/时间/互动量，不接受任何写操作，
不返回本机路径、Cookie 或其他凭证。token 不匹配直接 401。
"""
import argparse
import datetime
import json
import os
import secrets
import shutil
import subprocess
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

# 高产爆料号，和 references/accounts.md 保持一致
ACCOUNTS = [
    "644f177e000000001f0313af",
    "63ba54510000000027034228",
    "647d7b4f000000001c029e21",
    "602540730000000001008acb",
    "6837acdb000000001b023399",
    "68424a4a000000001d01547d",
    "68cb81ff000000002102824a",
    "66a4936a000000001d02377d",
]

CANDIDATES = [
    shutil.which("opencli"),
    os.path.expanduser("~/.local/bin/opencli"),
    "/opt/homebrew/bin/opencli",
    "/usr/local/bin/opencli",
]
OPENCLI = next((p for p in CANDIDATES if p and os.access(p, os.X_OK)), None)

TOKEN = os.environ.get("GUA_API_TOKEN") or secrets.token_urlsafe(24)


def run_opencli(args, timeout=60):
    if not OPENCLI:
        raise RuntimeError("opencli not found")
    out = subprocess.run(
        [OPENCLI, *args], capture_output=True, text=True, timeout=timeout
    )
    return out.stdout


def note_time(note_id):
    """笔记 ID 前 8 位是十六进制 Unix 时间戳。"""
    try:
        return datetime.datetime.fromtimestamp(int(note_id[:8], 16))
    except (ValueError, TypeError):
        return None


def collect(hours=24, limit=20):
    now = datetime.datetime.now()
    lower = now - datetime.timedelta(hours=hours)
    seen, rows = set(), []
    for uid in ACCOUNTS:
        try:
            data = json.loads(run_opencli(["xiaohongshu", "user", uid, "--limit", str(limit), "-f", "json"]) or "[]")
        except Exception:
            continue
        if not isinstance(data, list):
            continue
        for n in data:
            if not isinstance(n, dict):
                continue
            nid = n.get("id", "")
            t = note_time(nid)
            if not t or t < lower or nid in seen:
                continue
            seen.add(nid)
            rows.append({
                "id": nid,
                "published_at": t.strftime("%Y-%m-%d %H:%M:%S"),
                "title": n.get("title"),
                "likes": n.get("likes"),
                "url": n.get("url"),
                "cover": n.get("cover"),
            })
    rows.sort(key=lambda r: r["published_at"], reverse=True)
    return {
        "generated_at": now.strftime("%Y-%m-%d %H:%M:%S"),
        "window_hours": hours,
        "accounts_scanned": len(ACCOUNTS),
        "count": len(rows),
        "items": rows,
    }


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def _send(self, code, payload):
        body = json.dumps(payload, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)

        if u.path == "/health":
            doctor = ""
            try:
                doctor = run_opencli(["doctor"], timeout=20)
            except Exception as e:
                doctor = f"error: {e}"
            return self._send(200, {
                "opencli": OPENCLI or "not found",
                "bridge_ok": "Extension: connected" in doctor,
                "doctor": doctor.strip().splitlines()[:6],
            })

        auth = self.headers.get("Authorization", "")
        if auth != f"Bearer {TOKEN}":
            return self._send(401, {"error": "unauthorized"})

        if u.path == "/gua":
            hours = float(q.get("hours", ["24"])[0])
            limit = int(q.get("limit", ["20"])[0])
            try:
                return self._send(200, collect(hours, limit))
            except Exception as e:
                return self._send(500, {"error": str(e)})

        self._send(404, {"error": "not found"})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8787)
    args = ap.parse_args()

    if not OPENCLI:
        sys.exit("找不到 opencli，先确认它装好了")

    print(f"opencli: {OPENCLI}")
    print(f"listening on http://{args.host}:{args.port}")
    print(f"GUA_API_TOKEN={TOKEN}")
    if args.host != "127.0.0.1":
        print("注意：正在对外监听，确保 token 已保密")
    ThreadingHTTPServer((args.host, args.port), Handler).serve_forever()


if __name__ == "__main__":
    main()
