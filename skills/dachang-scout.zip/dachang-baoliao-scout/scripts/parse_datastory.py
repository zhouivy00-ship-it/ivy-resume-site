#!/usr/bin/env python3
"""解析数说故事（dc.datastory.com.cn）导出的 xlsx，筛出时间窗口内的候选瓜。

用法:
    python3 parse_datastory.py <xlsx路径> [--hours 24] [--now "2026-08-25 12:00"]

输出 Markdown 候选表到 stdout，供 agent 接着做打分和选题。
脚本只做机械筛选和去重，不做判断：有没有料、值不值得写由 agent 读了内容再定。
"""
import argparse
import re
import sys
import warnings

warnings.filterwarnings("ignore")

try:
    import pandas as pd
except ImportError:
    sys.exit("需要 pandas: pip3 install pandas openpyxl")

# 导出表里常见的列名，缺失的列会被跳过
COL_TITLE = "标题"
COL_CONTENT = "内容"
COL_AUTHOR = "作者"
COL_URL = "url"
COL_TIME = "发表时间"
COL_LIKES = "点赞数"
COL_COMMENTS = "评论数"
COL_INTERACT = "总互动量"
COL_SPAM = "是否水军"

# 明显跟大厂职场无关的内容，先机械滤掉一层，减少 agent 的阅读量
NOISE = re.compile(
    r"影视解说|穿搭|美食|探店|旅游|减脂|护肤|彩妆|宠物|考研英语|钢琴|装修|亲子",
)


def parse_time(series):
    """把「2026年08月24日 10:25:07」这种格式转成 datetime。实测成功率 100%。"""
    cleaned = (
        series.astype(str)
        .str.replace("年", "-", regex=False)
        .str.replace("月", "-", regex=False)
        .str.replace("日", "", regex=False)
        .str.strip()
    )
    return pd.to_datetime(cleaned, errors="coerce")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("xlsx")
    ap.add_argument("--hours", type=float, default=24)
    ap.add_argument("--now", default=None, help="基准时间，默认取表里最新一条")
    args = ap.parse_args()

    df = pd.read_excel(args.xlsx)
    if COL_TIME not in df.columns:
        sys.exit(f"表里没有「{COL_TIME}」列，确认导出时勾选了这个字段")

    df["_t"] = parse_time(df[COL_TIME])
    ok = df["_t"].notna().mean()
    total = len(df)

    now = pd.to_datetime(args.now) if args.now else df["_t"].max()
    lower = now - pd.Timedelta(hours=args.hours)
    win = df[(df["_t"] >= lower) & (df["_t"] <= now)].copy()

    # 去噪 + 去水军
    if COL_TITLE in win.columns:
        win = win[~win[COL_TITLE].astype(str).str.contains(NOISE, na=False)]
    if COL_SPAM in win.columns:
        win = win[win[COL_SPAM].astype(str).str.strip() != "是"]

    # 按主题去重：标题前 12 字相同的视为同一个瓜，保留互动量最高的
    if COL_TITLE in win.columns:
        win["_k"] = win[COL_TITLE].astype(str).str.replace(r"\W", "", regex=True).str[:12]
        sort_col = COL_INTERACT if COL_INTERACT in win.columns else COL_TITLE
        win = (
            win.sort_values(sort_col, ascending=False)
            .drop_duplicates("_k", keep="first")
        )

    win = win.sort_values("_t", ascending=False)

    print(f"### 数说导出表候选｜窗口 {lower:%Y-%m-%d %H:%M} ~ {now:%Y-%m-%d %H:%M}\n")
    print(f"- 源文件：`{args.xlsx}`")
    print(f"- 总行数 {total}，时间解析成功率 {ok:.1%}，窗口内去重去噪后 {len(win)} 条\n")

    if win.empty:
        print("窗口内没有候选。放宽 `--hours` 或在数说里重新导一份更近的表。")
        return

    print("| # | 时间 | 作者 | 标题 | 互动 | 链接 |")
    print("|---|---|---|---|---|---|")
    for i, (_, r) in enumerate(win.iterrows(), 1):
        inter = r.get(COL_INTERACT) or r.get(COL_LIKES) or ""
        print(
            f"| {i} | {r['_t']:%m-%d %H:%M} | {str(r.get(COL_AUTHOR, ''))[:12]} | "
            f"{str(r.get(COL_TITLE, ''))[:40]} | {inter} | {str(r.get(COL_URL, ''))} |"
        )

    print("\n---\n正文摘录（判断有没有料看这里）：\n")
    for i, (_, r) in enumerate(win.iterrows(), 1):
        body = re.sub(r"\s+", " ", str(r.get(COL_CONTENT, "")))[:300]
        print(f"**{i}. {str(r.get(COL_TITLE, ''))[:40]}**\n\n{body}\n")


if __name__ == "__main__":
    main()
